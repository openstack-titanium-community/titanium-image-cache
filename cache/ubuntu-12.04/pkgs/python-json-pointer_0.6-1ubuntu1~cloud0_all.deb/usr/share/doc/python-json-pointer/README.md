python-json-pointer [![Build Status](https://secure.travis-ci.org/stefankoegl/python-json-pointer.png?branch=master)](https://travis-ci.org/stefankoegl/python-json-pointer)
===================

Resolve JSON Pointers in Python
-------------------------------

Library to resolve JSON Pointers according to
http://tools.ietf.org/html/draft-ietf-appsawg-json-pointer-04

See Sourcecode for Examples
* Website: https://github.com/stefankoegl/python-json-pointer
* Repository: https://github.com/stefankoegl/python-json-pointer.git
